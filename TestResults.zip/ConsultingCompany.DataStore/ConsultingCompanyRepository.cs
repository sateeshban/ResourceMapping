﻿
namespace ConsultingCompany.DataStore
{
    using System.Collections.Generic;
    using ConsultingCompany.Lib;

    public class ConsultingCompanyRepository : IConsultingCompanyRepository
    {
        public ConsultingCompanyRepository()
        {
            Initialize();
        }

        private List<Resource> _resources = null;

        private List<Client> _clients = null;

        public List<Resource> Resources
        {
            get
            {
                return this._resources;
            }
        }


        public List<Client> Clients
        {
            get
            {
                return this._clients;
            }

        }

        public void Initialize()
        {
            this._resources = new List<Resource>()
                                  {
                                      new Resource() { FirstName = "Chris", LastName = "Smith", Type = ResourceType.Developer },
                                      new Resource() { FirstName = "Brian", LastName = "Jones", Type = ResourceType.Developer },
                                      new Resource() { FirstName = "Mary", LastName = "Bill", Type = ResourceType.Developer },
                                      new Resource() { FirstName = "Lin", LastName = "Mayer", Type = ResourceType.Developer },
                                      new Resource() { FirstName = "Jason", LastName = "Gold", Type = ResourceType.ProjectManager },
                                      new Resource() { FirstName = "Jennifer", LastName = "Mike", Type = ResourceType.ProjectManager },
                                      new Resource() { FirstName = "Bob", LastName = "Lawrence", Type = ResourceType.Architect },
                                      new Resource() { FirstName = "Susan", LastName = "Kennedy", Type = ResourceType.QA },
                                      new Resource() { FirstName = "Jerry", LastName = "Williams", Type = ResourceType.Architect },
                                      new Resource() { FirstName = "Eric", LastName = "Hammill", Type = ResourceType.QA }
                                  };

            this._clients = new List<Client>()
                                {
                                    new Client()
                                        {
                                            CompanyName = "Microsoft",
                                            ContactFirstName = "Bill",
                                            ContactLastName = "Gates",
                                            City="New York",
                                            State="New York",
                                            Zip=123456

                                        },
                                    new Client()
                                        {
                                            CompanyName = "Facebook",
                                            ContactFirstName = "Mark",
                                            ContactLastName = "Zuckerberg",
                                             City="New York",
                                            State="New York",
                                            Zip=123456
                                        },
                                    new Client()
                                        {
                                            CompanyName = "Amazon",
                                            ContactFirstName = "Jeff",
                                            ContactLastName = "Bezos",
                                            City="New York",
                                            State="New York",
                                            Zip=123456
                                        },
                                };
        }


    }
}
