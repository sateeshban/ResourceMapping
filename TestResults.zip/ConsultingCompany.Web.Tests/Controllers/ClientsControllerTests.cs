﻿using ConsultingCompany.Lib;
using ConsultingCompany.Web.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Mvc;
using Moq;
using System.Collections.Generic;
using System;

namespace ConsultingCompany.Web.Tests.Controllers
{
    [TestClass]
   public class ClientsControllerTests
    {
        private Mock<IConsultingCompanyRepository> _repository;

       List<Client> client=new List<Client>();

        [TestInitialize]
        public void Initialize()
        {
            _repository = new Mock<IConsultingCompanyRepository>();

            client.Add( new Client()
            {
                CompanyName = "Facebook",
                ContactFirstName = "Mark",
                ContactLastName = "Zuckerberg",
                City = "New Yark",
                State = "New Yark",
                Zip = 123456
            });
            _repository.Setup(ex => ex.Clients).Returns(client);

        }


        [TestMethod]
        public void Index()
        {
            // Arrange
            ClientsController controller = new ClientsController(_repository.Object);

            // Act
            ViewResult result = controller.Index() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void Index_ErrorHandling()
        {
            // Arrange
            ClientsController controller = new ClientsController(null);

            // Act
            ViewResult result = controller.Index() as ViewResult;

            // Assert
        }

        [TestMethod]
        public void details()
        {
            // Arrange
            ClientsController controller = new ClientsController(_repository.Object);

            // Act
            ViewResult result = controller.Details("Facebook") as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void Create()
        {
            // Arrange
            ClientsController controller = new ClientsController(_repository.Object);

            // Act
            ViewResult result = controller.Create() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }
        [TestMethod]
        public void CreatePost()
        {
            // Arrange
            ClientsController controller = new ClientsController(_repository.Object);
            FormCollection collection = new FormCollection();
            collection.Add("CompanyName", "Facebook");
            collection.Add("ContactFirstName", "Mark");
            collection.Add("ContactLastName", "Zuckerberg");
            collection.Add("City", "New York");
            collection.Add("State", "New York");
            collection.Add("Zip", "12345");
           
            // Act
            ActionResult result = controller.Create(collection) as ActionResult;

            // Assert
            Assert.IsNotNull(result);
        }
        [TestMethod]
        public void Edit()
        {
            // Arrange
            ClientsController controller = new ClientsController(_repository.Object);

            // Act
            ViewResult result = controller.Edit("Facebook") as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }
        [TestMethod]
        public void EditPost()
        {
            // Arrange
            ClientsController controller = new ClientsController(_repository.Object);
            FormCollection collection = new FormCollection();
            collection.Add("CompanyName", "Facebook");
            collection.Add("ContactFirstName", "Mark");
            collection.Add("ContactLastName", "Zuckerberg");
            collection.Add("City", "New York");
            collection.Add("State", "New York");
            collection.Add("Zip", "12345");

            // Act
            ActionResult result = controller.Edit("Facebook", collection) as ActionResult;

            // Assert
            Assert.IsNotNull(result);
        }

        public void Delete()
        {
            // Arrange
            ClientsController controller = new ClientsController(_repository.Object);

            // Act
            ViewResult result = controller.Delete("Facebook") as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }

       
    }
}