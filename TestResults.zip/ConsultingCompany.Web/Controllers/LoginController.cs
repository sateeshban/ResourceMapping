﻿using ConsultingCompany.Lib;
using ConsultingCompany.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace ConsultingCompany.Web.Controllers
{
    public class LoginController : Controller
    {

        IConsultingCompanyRepository repository;
        public LoginController(IConsultingCompanyRepository pRepository)
        {
            repository = pRepository;
        }
        // GET: Login
        public ActionResult Index()
        {
            FormsAuthentication.SignOut();
            LoginModel model = new LoginModel()
            {
                isNotValid = false
            };
            return View("Login", model);
        }


        // POST: Login/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {

                var Name = collection["UserName"];
                var password = collection["Password"];
                Session["name"] = Name;
                var result = repository.Resources.Where(ex => ex.FirstName == Name).Select(ex => ex).FirstOrDefault();
                if (result != null)
                {

                    FormsAuthentication.SetAuthCookie(Name, false);

                    var authTicket = new FormsAuthenticationTicket(1, Name, DateTime.Now, DateTime.Now.AddMinutes(20), false, result.Type.ToString());
                    string encryptedTicket = FormsAuthentication.Encrypt(authTicket);
                    var authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);
                    HttpContext.Response.Cookies.Add(authCookie);
                    return RedirectToAction("Index", "Clients");


                }
                else
                {
                    LoginModel model = new LoginModel()
                    {
                        isNotValid = true
                    };
                    return View("Login", model);
                }

            }
            catch
            {
                return View();
            }
        }


    }
}
