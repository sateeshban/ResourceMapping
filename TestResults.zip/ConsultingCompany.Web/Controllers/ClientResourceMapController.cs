﻿using ConsultingCompany.Lib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ConsultingCompany.Web.Controllers
{
    public class ClientResourceMapController : Controller
    {
        IConsultingCompanyRepository repository;
        public ClientResourceMapController(IConsultingCompanyRepository pRepository)
        {
            repository = pRepository;
        }

        // GET: ClientResourceMap
        [Authorize(Roles = "Architect,ProjectManager")]
        [ErrorHandling(ExceptionType = typeof(NotImplementedException), View = "Error")]
        public ActionResult Index()
        {
            return View();
        }

        // GET: ClientResourceMap/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: ClientResourceMap/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ClientResourceMap/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: ClientResourceMap/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: ClientResourceMap/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: ClientResourceMap/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: ClientResourceMap/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
