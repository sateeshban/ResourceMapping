﻿using ConsultingCompany.Lib;
using ConsultingCompany.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace ConsultingCompany.Web.Controllers
{
    public class ClientsController : Controller
    {
        IConsultingCompanyRepository repository;
        public ClientsController(IConsultingCompanyRepository pRepository)
        {
            repository = pRepository;
        }
        // GET: Clients
        [ErrorHandling(ExceptionType = typeof(NotImplementedException), View = "Error")]
        public ActionResult Index()
        {

            var clientdata = repository.Clients.Select(ex =>
                                           new ClientModel
                                           {
                                               City = ex.City,
                                               CompanyName = ex.CompanyName,
                                               ContactFirstName = ex.ContactFirstName,
                                               ContactLastName = ex.ContactLastName,
                                               State = ex.State,
                                               Zip = ex.Zip

                                           }).ToList();

            return View(clientdata);
        }

        [ErrorHandling(ExceptionType = typeof(NotImplementedException), View = "Error")]
       public ActionResult Details(string CompanyName)
        {
            var clientdata = repository.Clients.Where(ex => ex.CompanyName == CompanyName).Select(ex =>
                                               new ClientModel
                                               {
                                                   City = ex.City,
                                                   CompanyName = ex.CompanyName,
                                                   ContactFirstName = ex.ContactFirstName,
                                                   ContactLastName = ex.ContactLastName,
                                                   State = ex.State,
                                                   Zip = ex.Zip

                                               }).FirstOrDefault();

            return View("ClientDetails", clientdata);

        }

        [ErrorHandling(ExceptionType = typeof(NotImplementedException), View = "Error")]

        public ActionResult Create()
        {
            return View();
        }

        // POST: Clients/Create
        [HttpPost]
        [ErrorHandling(ExceptionType = typeof(NotImplementedException), View = "Error")]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                var clientData = new Client()
                {
                    CompanyName = collection["CompanyName"],
                    ContactFirstName = collection["ContactFirstName"],
                    ContactLastName = collection["ContactLastName"],
                    City = collection["City"],
                    State = collection["State"],
                    Zip = Convert.ToInt64(collection["Zip"])
                };

                repository.Clients.Add(clientData);
                ViewData["Clients"] = repository.Clients;
                return View("UpdatedView");
            }
            catch
            {

                return View();
            }
        }

        [ErrorHandling(ExceptionType = typeof(NotImplementedException), View = "Error")]
        public ActionResult Edit(string CompanyName)
        {
            var clientdata = repository.Clients.Where(ex => ex.CompanyName == CompanyName).Select(ex =>
                                               new ClientModel
                                               {
                                                   City = ex.City,
                                                   CompanyName = ex.CompanyName,
                                                   ContactFirstName = ex.ContactFirstName,
                                                   ContactLastName = ex.ContactLastName,
                                                   State = ex.State,
                                                   Zip = ex.Zip

                                               }).FirstOrDefault();
            return View("UpdateClient", clientdata);
        }

        // POST: Clients/Edit/5
        [HttpPost]
        [ErrorHandling(ExceptionType = typeof(NotImplementedException), View = "Error")]
        public ActionResult Edit(string companyName, FormCollection collection)
        {
            try
            {
                var clientData = new Client()
                {
                    CompanyName = companyName,
                    ContactFirstName = collection["ContactFirstName"],
                    ContactLastName = collection["ContactLastName"],
                    City = collection["City"],
                    State = collection["State"],
                    Zip = Convert.ToInt64(collection["Zip"])
                };
                var result = repository.Clients.Where(ex => ex.CompanyName == companyName).Select(ex => ex).FirstOrDefault();
                var clientdata = repository.Clients.Remove(result);
                repository.Clients.Add(clientData);
                ViewData["Clients"] = repository.Clients;
                return View("UpdatedView");
            }
            catch
            {
                return View();
            }
        }

        [ErrorHandling(ExceptionType = typeof(NotImplementedException), View = "Error")]
        public ActionResult Delete(string CompanyName)
        {
            var result = repository.Clients.Where(ex => ex.CompanyName == CompanyName).Select(ex => ex).FirstOrDefault();
            var clientdata = repository.Clients.Remove(result);
            ViewData["Clients"] = repository.Clients;
            return View("UpdatedView"); ;
        }

        [ErrorHandling(ExceptionType = typeof(NotImplementedException), View = "Error")]
        public ActionResult UpdatedView()
        {
            return View();
        }
    }
}
