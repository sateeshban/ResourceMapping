﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ConsultingCompany.Web.Models
{
    public class ClientModel
    {
        [Required(ErrorMessage = "CompanyName Required")]
        public string CompanyName { get; set; }
        [Required(ErrorMessage = "ContactFirstName Required")]
        public string ContactFirstName { get; set; }
        [Required(ErrorMessage = "ContactLastName Required")]
        public string ContactLastName { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public long Zip { get; set; }
    }
}