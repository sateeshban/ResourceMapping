﻿using Autofac;
using Autofac.Integration.Mvc;
using ConsultingCompany.DataStore;
using ConsultingCompany.Lib;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;

namespace ConsultingCompany.Web.App_Start
{
    public class IoCConfig
    {
        public static void RegisterDependencies()
        {
            var builder = new ContainerBuilder();
            builder.RegisterControllers(Assembly.GetExecutingAssembly());
            builder.RegisterSource(new ViewRegistrationSource());

            // manual registration of types;
            builder.RegisterType<ConsultingCompanyRepository>().As<IConsultingCompanyRepository>();
            builder.RegisterAssemblyModules(typeof(MvcApplication).Assembly);
            builder.RegisterModule<AutofacWebTypesModule>();
            var container = builder.Build();
            DependencyResolver.SetResolver(new AutofacDependencyResolver(container));


        }
    }
}