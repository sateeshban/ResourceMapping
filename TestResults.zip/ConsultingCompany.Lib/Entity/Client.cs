﻿namespace ConsultingCompany.Lib
{
    public class Client
    {
        public string CompanyName { get; set; }

        public string ContactFirstName { get; set; }

        public string ContactLastName { get; set; }

        public string City { get; set; }
        public string State { get; set; }
        public long Zip { get; set; }
    }
}